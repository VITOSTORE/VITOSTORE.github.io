document.addEventListener('DOMContentLoaded', () => {

    // Sidebar Toggle for mobile
    const sidebar = document.querySelector('.sidebar');
    const toggleBtn = document.querySelector('.header__toggle');

    if(toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('open');
        });
    }

    // Sales Chart (using Chart.js)
    const salesCanvas = document.getElementById('salesChart');
    if (salesCanvas) {
        const ctx = salesCanvas.getContext('2d');
        
        // البيانات هنا ستأتي من الواجهة الخلفية
        const salesData = {
            labels: ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'],
            datasets: [{
                label: 'المبيعات (بالجنيه)',
                data: [12000, 19000, 15000, 25000, 22000, 30000, 28000],
                backgroundColor: 'rgba(79, 70, 229, 0.1)',
                borderColor: 'rgba(79, 70, 229, 1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        };

        new Chart(ctx, {
            type: 'line',
            data: salesData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
});