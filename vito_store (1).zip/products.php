<?php
// تضمين ملف الاتصال بقاعدة البيانات
require_once "config.php";

// الإعدادات الافتراضية
$products_per_page = 12; // عدد المنتجات في كل صفحة
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $products_per_page;

// بناء استعلام SQL بناءً على الفلاتر والترتيب
$sql = "SELECT p.* FROM products p";
$count_sql = "SELECT COUNT(DISTINCT p.id) FROM products p";

// التعامل مع فلتر الفئات
if (!empty($_GET['categories']) && is_array($_GET['categories'])) {
    $category_ids = implode(',', array_map('intval', $_GET['categories']));
    $sql .= " JOIN product_categories pc ON p.id = pc.product_id WHERE pc.category_id IN ($category_ids)";
    $count_sql .= " JOIN product_categories pc ON p.id = pc.product_id WHERE pc.category_id IN ($category_ids)";
}

// التعامل مع الترتيب
$sort_order = ' ORDER BY p.created_at DESC'; // الترتيب الافتراضي
if (!empty($_GET['sort'])) {
    switch ($_GET['sort']) {
        case 'price_asc':
            $sort_order = ' ORDER BY p.price ASC';
            break;
        case 'price_desc':
            $sort_order = ' ORDER BY p.price DESC';
            break;
        case 'newest':
            $sort_order = ' ORDER BY p.created_at DESC';
            break;
    }
}
$sql .= $sort_order;

// حساب إجمالي عدد المنتجات (لترقيم الصفحات)
$count_result = mysqli_query($link, $count_sql);
$total_products = mysqli_fetch_row($count_result)[0];
$total_pages = ceil($total_products / $products_per_page);

// إضافة حدود لجلب المنتجات للصفحة الحالية
$sql .= " LIMIT $products_per_page OFFSET $offset";
$result_products = mysqli_query($link, $sql);

// جلب كل الفئات لعرضها في الفلتر
$result_categories = mysqli_query($link, "SELECT * FROM categories ORDER BY name ASC");
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>المنتجات - VITO STORE</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header class="header" id="header">
        </header>

    <main>
        <section class="page__header">
            <div class="container">
                <h1 class="page__title">كل المنتجات</h1>
                <ul class="breadcrumbs">
                    <li><a href="index.php">الرئيسية</a></li>
                    <li>/</li>
                    <li>المنتجات</li>
                </ul>
            </div>
        </section>

        <section class="shop section">
            <form method="GET" action="products.php" id="filter-form">
                <div class="shop__container container">
                    <aside class="shop__filters" id="shop-filters">
                        <div class="filters__header">
                            <h3>الفلاتر</h3>
                            <i class='bx bx-x filters__close' id="filters-close"></i>
                        </div>

                        <div class="filter__group">
                            <h4 class="filter__title">الفئات</h4>
                            <ul class="filter__list">
                                <?php
                                if (mysqli_num_rows($result_categories) > 0) {
                                    while ($category = mysqli_fetch_assoc($result_categories)) {
                                        $checked = (isset($_GET['categories']) && in_array($category['id'], $_GET['categories'])) ? 'checked' : '';
                                        echo '<li><input type="checkbox" name="categories[]" value="' . $category['id'] . '" id="cat' . $category['id'] . '" ' . $checked . '><label for="cat' . $category['id'] . '">' . htmlspecialchars($category['name']) . '</label></li>';
                                    }
                                }
                                ?>
                            </ul>
                        </div>
                        
                        <button type="submit" class="button filter__button">تطبيق الفلتر</button>
                    </aside>

                    <div class="shop__content">
                        <div class="shop__header">
                            <button type="button" class="button--link filters-toggle" id="filters-toggle">
                                <i class='bx bx-filter-alt'></i> عرض الفلاتر
                            </button>
                            <select name="sort" class="shop__sort" onchange="document.getElementById('filter-form').submit()">
                                <option value="newest" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'newest') ? 'selected' : ''; ?>>الأحدث</option>
                                <option value="price_asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_asc') ? 'selected' : ''; ?>>السعر: من الأقل للأعلى</option>
                                <option value="price_desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_desc') ? 'selected' : ''; ?>>السعر: من الأعلى للأقل</option>
                            </select>
                        </div>

                        <div class="products__container grid">
                            <?php
                            if (mysqli_num_rows($result_products) > 0) {
                                while ($product = mysqli_fetch_assoc($result_products)) {
                                    echo '<div class="product__card">';
                                    echo '    <div class="product__image"><a href="single-product.php?id=' . $product['id'] . '"><img src="' . htmlspecialchars($product['image_url']) . '" alt="' . htmlspecialchars($product['name']) . '"></a></div>';
                                    echo '    <div class="product__data">';
                                    echo '        <h3 class="product__name">' . htmlspecialchars($product['name']) . '</h3>';
                                    echo '        <p class="product__price">' . number_format($product['price'], 2) . ' جنيه</p>';
                                    echo '       echo '<form action="cart-handler.php" method="POST">';
                                      echo ' <input type="hidden" name="product_id" value="' . $product['id'] . '">';
                                      echo ' <input type="hidden" name="quantity" value="1">';
                                      echo ' <input type="hidden" name="action" value="add">';
                                      echo ' <button type="submit" class="button product__button">';
                                        echo ' <i class="bx bx-cart-add"></i><span>أضف للسلة</span>';
                                        echo ' </button>';
                                      echo '</form>';
                                    echo '    </div>';
                                    echo '</div>';
                                }
                            } else {
                                echo '<p>لا توجد منتجات تطابق هذه الفلاتر.</p>';
                            }
                            ?>
                        </div>

                        <nav class="pagination">
                            <ul class="pagination__list">
                                <?php
                                if ($total_pages > 1) {
                                    for ($i = 1; $i <= $total_pages; $i++) {
                                        // الحفاظ على الفلاتر والترتيب عند التنقل بين الصفحات
                                        $query_params = $_GET;
                                        $query_params['page'] = $i;
                                        $href = 'products.php?' . http_build_query($query_params);
                                        $class = ($page == $i) ? 'current' : '';
                                        echo '<li><a href="' . $href . '" class="pagination__link ' . $class . '">' . $i . '</a></li>';
                                    }
                                }
                                ?>
                            </ul>
                        </nav>
                    </div>
                </div>
            </form>
        </section>
    </main>

    <footer class="footer section">
        </footer>

    <a href="#" class="scrollup" id="scroll-up"><i class='bx bx-up-arrow-alt scrollup__icon'></i></a>

    <script src="script.js"></script>
</body>
</html>