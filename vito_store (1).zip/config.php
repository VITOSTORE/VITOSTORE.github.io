<?php
// إعدادات الاتصال بقاعدة البيانات
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root'); // اسم المستخدم الافتراضي في XAMPP هو root
define('DB_PASSWORD', ''); // كلمة المرور الافتراضية في XAMPP فارغة
define('DB_NAME', 'vito_store_db');

// محاولة الاتصال بقاعدة البيانات
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// التحقق من الاتصال
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// ضبط الترميز إلى utf8mb4 لضمان دعم اللغة العربية بشكل صحيح
mysqli_set_charset($link, "utf8mb4");
?>