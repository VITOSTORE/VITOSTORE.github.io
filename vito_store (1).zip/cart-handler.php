<?php
// بدء الجلسة في كل مرة يتم فيها التعامل مع السلة
session_start();

// التحقق من وجود سلة في الجلسة، وإلا يتم إنشاؤها
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// التحقق من أن الطلب هو POST
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {

    $product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;

    switch ($_POST['action']) {
        // حالة إضافة منتج للسلة
        case 'add':
            $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
            if ($product_id > 0 && $quantity > 0) {
                // إذا كان المنتج موجودًا بالفعل، قم بزيادة الكمية
                if (isset($_SESSION['cart'][$product_id])) {
                    $_SESSION['cart'][$product_id]['quantity'] += $quantity;
                } else {
                    // إذا كان المنتج جديدًا، أضفه للسلة
                    $_SESSION['cart'][$product_id] = ['quantity' => $quantity];
                }
            }
            // بعد الإضافة، قم بإعادة توجيه المستخدم إلى صفحة السلة
            header('Location: cart.php');
            exit();

        // حالة تحديث كمية منتج
        case 'update':
            $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
            if ($product_id > 0 && isset($_SESSION['cart'][$product_id])) {
                if ($quantity > 0) {
                    $_SESSION['cart'][$product_id]['quantity'] = $quantity;
                } else {
                    // إذا كانت الكمية صفرًا أو أقل، احذف المنتج
                    unset($_SESSION['cart'][$product_id]);
                }
            }
            header('Location: cart.php');
            exit();
            
        // حالة حذف منتج من السلة
        case 'remove':
            if ($product_id > 0 && isset($_SESSION['cart'][$product_id])) {
                unset($_SESSION['cart'][$product_id]);
            }
            header('Location: cart.php');
            exit();
    }
}

// إذا تم الوصول للملف مباشرة، قم بإعادة التوجيه للصفحة الرئيسية
header('Location: index.php');
exit();
?>