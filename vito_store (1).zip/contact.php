<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تواصل معنا - VITO STORE</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header class="header" id="header">
        <nav class="nav container">
            <a href="index.html" class="nav__logo">VITO</a>
            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                    <li class="nav__item"><a href="index.html#home" class="nav__link"><i class='bx bx-home-alt-2'></i><span>الرئيسية</span></a></li>
                    <li class="nav__item"><a href="products.html" class="nav__link"><i class='bx bx-shopping-bag'></i><span>المنتجات</span></a></li>
                    <li class="nav__item"><a href="bestsellers.html" class="nav__link"><i class='bx bxs-purchase-tag'></i><span>الأكثر مبيعًا</span></a></li>
                    <li class="nav__item"><a href="contact.html" class="nav__link active-link"><i class='bx bx-phone'></i><span>تواصل</span></a></li>
                </ul>
            </div>
            <div class="nav__actions">
                <i class='bx bx-search nav__icon'></i>
                <i class='bx bx-shopping-bag nav__icon'></i>
                <i class='bx bx-user nav__icon'></i>
            </div>
        </nav>
    </header>

    <main>
        <section class="page__header">
            <div class="container">
                <h1 class="page__title">تواصل معنا</h1>
                <ul class="breadcrumbs">
                    <li><a href="index.html">الرئيسية</a></li>
                    <li>/</li>
                    <li>تواصل معنا</li>
                </ul>
            </div>
        </section>

        <section class="contact section">
            <div class="contact__container container grid">
                <div class="contact__info">
                    <h3 class="contact__title">معلومات التواصل</h3>
                    <p class="contact__description">
                        نحن هنا لمساعدتك. يمكنك التواصل معنا عبر القنوات التالية أو ملء النموذج.
                    </p>

                    <div class="contact__card">
                        <i class='bx bxs-phone-call contact__card-icon'></i>
                        <div>
                            <h4>الهاتف</h4>
                            <a href="tel:+201001234567" class="contact__card-data">+20-100-123-4567</a>
                        </div>
                    </div>

                    <div class="contact__card">
                        <i class='bx bxs-envelope contact__card-icon'></i>
                        <div>
                            <h4>البريد الإلكتروني</h4>
                            <a href="mailto:support@vitostore.com" class="contact__card-data">support@vitostore.com</a>
                        </div>
                    </div>
                    
                    <div class="contact__card">
                        <i class='bx bxs-map contact__card-icon'></i>
                        <div>
                            <h4>العنوان</h4>
                            <p class="contact__card-data">123 شارع التسوق، القاهرة، مصر</p>
                        </div>
                    </div>
                </div>

                <div class="contact__form-container">
                    <h3 class="contact__title">أو أرسل لنا رسالة</h3>
                    
                    <form action="process_contact.php" method="POST" class="contact__form">
                        <div class="form__group">
                            <label for="name" class="form__label">الاسم الكامل</label>
                            <input type="text" id="name" name="customer_name" class="form__input" required>
                        </div>
                        <div class="form__group">
                            <label for="email" class="form__label">البريد الإلكتروني</label>
                            <input type="email" id="email" name="customer_email" class="form__input" required>
                        </div>
                        <div class="form__group">
                            <label for="message" class="form__label">رسالتك</label>
                            <textarea id="message" name="customer_message" rows="6" class="form__input" required></textarea>
                        </div>
                        <button type="submit" class="button">إرسال الرسالة</button>
                    </form>
                </div>
            </div>

            <div class="contact__map container">
                 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d221151.3096307309!2d31.22235948955217!3d30.01637774229977!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14584034f7887539%3A0x89c28892a0e49528!2sCairo%2C%20Cairo%20Governorate!5e0!3m2!1sen!2seg!4v1673475943000!5m2!1sen!2seg" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </section>
    </main>

    <footer class="footer section">
        </footer>

    <a href="#" class="scrollup" id="scroll-up"><i class='bx bx-up-arrow-alt scrollup__icon'></i></a>

    <script src="script.js"></script>

</body>
</html>