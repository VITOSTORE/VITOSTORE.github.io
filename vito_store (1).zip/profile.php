<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>حسابي - VITO STORE</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
</head>
<body>

     <header class="header" id="header">
           <nav class="nav container">
             <a href="#" class="nav__logo">VITO</a>
        
             <div class="nav__menu" id="nav-menu">
               <ul class="nav__list">
                 <li class="nav__item">
                   <a href="#home" class="nav__link active-link">
                     <i class='bx bx-home-alt-2'></i>
                     <span>الرئيسية</span>
                   </a>
                 </li>
                 <li class="nav__item">
                   <a href="products.html" class="nav__link">
                     <i class='bx bx-shopping-bag'></i>
                     <span>المنتجات</span>
                   </a>
                 </li>
                 <li class="nav__item">
                   <a href="bestsellers.html" class="nav__link">
                     <i class='bx bxs-purchase-tag'></i>
                     <span>الأكثر مبيعًا</span>
                   </a>
                 </li>
        
                 <li class="nav__item">
                   <a href="cart.html" class="nav__link">
                     <i class='bx bx-cart'></i>
                     <span>السله</span>
                   </a>
                 </li>
        
                 <li class="nav__item">
                   <a href="#contact" class="nav__link">
                     <i class='bx bx-phone'></i>
                     <span>تواصل</span>
                   </a>
                 </li>
               </ul>
             </div>
        
             <div class="nav__actions">
               <i class='bx bx-search nav__icon' id="search-btn"></i>
               <i class='bx bx-shopping-bag nav__icon' id="cart-btn"></i>
               <i class='bx bx-user nav__icon' id="login-btn"></i>
               <i class='bx bx-menu nav__toggle' id="nav-toggle"></i>
             </div>
           </nav>
         </header>

    <main>
        <section class="page__header">
            <div class="container">
                <h1 class="page__title">حسابي</h1>
                <ul class="breadcrumbs">
                    <li><a href="index.html">الرئيسية</a></li>
                    <li>/</li>
                    <li>حسابي</li>
                </ul>
            </div>
        </section>

        <section class="profile section">
            <div class="profile__container container grid">
                <aside class="profile__nav">
                    <ul>
                        <li>
                            <a href="#" class="profile__nav-link active" data-target="dashboard">
                                <i class='bx bxs-dashboard'></i> لوحة التحكم
                            </a>
                        </li>
                        <li>
                            <a href="#" class="profile__nav-link" data-target="orders">
                                <i class='bx bxs-package'></i> طلباتي
                            </a>
                        </li>
                        <li>
                            <a href="#" class="profile__nav-link" data-target="details">
                                <i class='bx bxs-user-detail'></i> تفاصيلي الشخصية
                            </a>
                        </li>
                        <li>
                            <a href="#" class="profile__nav-link" data-target="addresses">
                                <i class='bx bxs-map-pin'></i> العناوين
                            </a>
                        </li>
                        <li>
                            <a href="#" class="profile__nav-link">
                                <i class='bx bx-log-out'></i> تسجيل الخروج
                            </a>
                        </li>
                    </ul>
                </aside>

                <div class="profile__content">
                    <div class="profile__panel" id="dashboard">
                        <h3>أهلاً بك، [اسم المستخدم]!</h3>
                        <p>من هنا يمكنك عرض طلباتك الأخيرة، إدارة عناوين الشحن، وتعديل كلمة المرور وتفاصيل حسابك.</p>
                    </div>

                    <div class="profile__panel hidden" id="orders">
                        <h3>طلباتي</h3>
                        <div class="order-history__table">
                            <div class="order-history__header grid">
                                <span>رقم الطلب</span>
                                <span>التاريخ</span>
                                <span>الحالة</span>
                                <span>الإجمالي</span>
                                <span></span>
                            </div>
                            <div class="order-history__item grid">
                                <span>#VITO-1051</span>
                                <span>20 يوليو 2025</span>
                                <span><span class="status status--delivered">تم التوصيل</span></span>
                                <span>1150.00 جنيه</span>
                                <span><a href="#" class="button--link">عرض التفاصيل</a></span>
                            </div>
                             <div class="order-history__item grid">
                                <span>#VITO-1045</span>
                                <span>15 يونيو 2025</span>
                                <span><span class="status status--shipped">تم الشحن</span></span>
                                <span>600.00 جنيه</span>
                                <span><a href="#" class="button--link">عرض التفاصيل</a></span>
                            </div>
                        </div>
                    </div>

                    <div class="profile__panel hidden" id="details">
                        <h3>تفاصيلي الشخصية</h3>
                        <form action="update_details.php" method="POST" class="contact__form">
                            <div class="form__group">
                                <label for="profile-name">الاسم الكامل</label>
                                <input type="text" id="profile-name" name="profile_name" class="form__input" value="[اسم المستخدم الحالي]">
                            </div>
                             <div class="form__group">
                                <label for="profile-email">البريد الإلكتروني</label>
                                <input type="email" id="profile-email" name="profile_email" class="form__input" value="[بريد المستخدم]" readonly>
                            </div>
                            <h4 class="form__divider">تغيير كلمة المرور</h4>
                             <div class="form__group">
                                <label for="current-password">كلمة المرور الحالية</label>
                                <input type="password" id="current-password" name="current_password" class="form__input">
                            </div>
                            <div class="form__group">
                                <label for="new-password">كلمة المرور الجديدة</label>
                                <input type="password" id="new-password" name="new_password" class="form__input">
                            </div>
                            <button type="submit" class="button">حفظ التغييرات</button>
                        </form>
                    </div>

                    <div class="profile__panel hidden" id="addresses">
                        <h3>العناوين المحفوظة</h3>
                        <div class="address__card">
                            <p><strong>العنوان الأساسي:</strong> 123 شارع التسوق، القاهرة، مصر</p>
                            <div>
                                <a href="#" class="button--link">تعديل</a>
                                <a href="#" class="button--link text-danger">حذف</a>
                            </div>
                        </div>
                        <button class="button button--outline">إضافة عنوان جديد</button>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <a href="#" class="scrollup" id="scroll-up"><i class='bx bx-up-arrow-alt scrollup__icon'></i></a>

    <script src="script.js"></script>
</body>
</html>