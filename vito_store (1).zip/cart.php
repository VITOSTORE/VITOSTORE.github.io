<?php
session_start();
require_once "config.php";

$cart_items = [];
$subtotal = 0;
$cart_is_empty = true;

if (!empty($_SESSION['cart'])) {
    $cart_is_empty = false;
    
    // استخراج IDs المنتجات من السلة لجلب بياناتها من قاعدة البيانات
    $product_ids = array_keys($_SESSION['cart']);
    $ids_string = implode(',', $product_ids);
    
    $sql = "SELECT * FROM products WHERE id IN ($ids_string)";
    $result = mysqli_query($link, $sql);
    
    $products_data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $products_data[$row['id']] = $row;
    }

    // تجهيز مصفوفة المنتجات النهائية للعرض وحساب الإجمالي
    foreach ($_SESSION['cart'] as $id => $item) {
        if (isset($products_data[$id])) {
            $product = $products_data[$id];
            $quantity = $item['quantity'];
            $total_price = $product['price'] * $quantity;
            $subtotal += $total_price;
            
            $cart_items[] = [
                'id' => $id,
                'name' => $product['name'],
                'price' => $product['price'],
                'image_url' => $product['image_url'],
                'quantity' => $quantity,
                'total_price' => $total_price
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سلة التسوق - VITO STORE</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="header" id="header">
        </header>

    <main>
        <section class="page__header">
            </section>

        <section class="cart section">
            <div class="cart-page-container container">
                
                <div class="cart__container grid <?php if ($cart_is_empty) echo 'hidden'; ?>">
                    <div class="cart__items">
                        <div class="cart__item-header grid">
                            <h4 class="cart__header-title">المنتج</h4>
                            <h4 class="cart__header-title">السعر</h4>
                            <h4 class="cart__header-title">الكمية</h4>
                            <h4 class="cart__header-title">الإجمالي</h4>
                            <h4 class="cart__header-title"></h4>
                        </div>
                        
                        <?php foreach ($cart_items as $item): ?>
                        <div class="cart__item grid">
                            <div class="cart__item-product">
                                <img src="<?php echo htmlspecialchars($item['image_url']); ?>" class="cart__item-img" alt="">
                                <div>
                                    <h3 class="cart__item-name"><?php echo htmlspecialchars($item['name']); ?></h3>
                                </div>
                            </div>
                            <div class="cart__item-price"><?php echo number_format($item['price'], 2); ?> جنيه</div>
                            <div class="cart__item-quantity">
                                <form action="cart-handler.php" method="POST" class="quantity-form">
                                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                    <input type="hidden" name="action" value="update">
                                    <input type="number" name="quantity" class="quantity-input" value="<?php echo $item['quantity']; ?>" min="1" onchange="this.form.submit()">
                                </form>
                            </div>
                            <div class="cart__item-total"><?php echo number_format($item['total_price'], 2); ?> جنيه</div>
                            <form action="cart-handler.php" method="POST">
                                <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                <input type="hidden" name="action" value="remove">
                                <button type="submit" class="cart__item-remove"><i class='bx bx-trash'></i></button>
                            </form>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="cart__summary">
                        <h3 class="cart__summary-title">ملخص الطلب</h3>
                        <div class="summary__line">
                            <span>المجموع الفرعي</span>
                            <span id="cart-subtotal"><?php echo number_format($subtotal, 2); ?> جنيه</span>
                        </div>
                        <div class="summary__line">
                            <span>الشحن</span>
                            <span>يتم تحديده لاحقًا</span>
                        </div>
                        <div class="summary__line summary__line--total">
                            <span>الإجمالي</span>
                            <span id="cart-total"><?php echo number_format($subtotal, 2); ?> جنيه</span>
                        </div>
                        <a href="checkout.php" class="button cart__summary-checkout">الانتقال للدفع</a>
                        <a href="products.php" class="button--link">متابعة التسوق</a>
                    </div>
                </div>

                <div class="cart-empty <?php if (!$cart_is_empty) echo 'hidden'; ?>">
                    <i class='bx bx-shopping-bag'></i>
                    <h2>سلة التسوق فارغة</h2>
                    <p>لم تقم بإضافة أي منتجات إلى سلتك بعد.</p>
                    <a href="products.php" class="button">ابدأ التسوق الآن</a>
                </div>

            </div>
        </section>
    </main>
    
    <footer class="footer section">
        </footer>
    <script src="script.js"></script>
</body>
</html>