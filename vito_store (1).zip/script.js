/*=============== CHANGE BACKGROUND HEADER ===============*/
function scrollHeader(){
    const header = document.getElementById('header')
    // When the scroll is greater than 50 viewport height, add the scroll-header class to the header tag
    if(this.scrollY >= 50) header.classList.add('scroll-header'); else header.classList.remove('scroll-header')
}
window.addEventListener('scroll', scrollHeader)


/*=============== SHOW SCROLL UP ===============*/ 
function scrollUp(){
    const scrollUp = document.getElementById('scroll-up');
    // When the scroll is higher than 350 viewport height, add the show-scroll class to the a tag with the scroll-top class
    if(this.scrollY >= 350) scrollUp.classList.add('show-scroll'); else scrollUp.classList.remove('show-scroll')
}
window.addEventListener('scroll', scrollUp)


/*=============== SCROLL SECTIONS ACTIVE LINK ===============*/
const sections = document.querySelectorAll('section[id]')

function scrollActive(){
    const scrollY = window.pageYOffset

    sections.forEach(current =>{
        const sectionHeight = current.offsetHeight,
              sectionTop = current.offsetTop - 58,
              sectionId = current.getAttribute('id')

        if(scrollY > sectionTop && scrollY <= sectionTop + sectionHeight){
            document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.add('active-link')
        }else{
            document.querySelector('.nav__menu a[href*=' + sectionId + ']').classList.remove('active-link')
        }
    })
}
window.addEventListener('scroll', scrollActive)


/*=============== Mobile Nav Toggle (Placeholder) ===============*/
// This is a basic toggle for the mobile menu if you decide to implement it differently in the future.
// The current CSS handles the bottom bar menu, so this is optional.
const navToggle = document.getElementById('nav-toggle');
const navMenu = document.getElementById('nav-menu');

if (navToggle && navMenu) {
    // A simple console log to show the elements are ready for interaction logic
    navToggle.addEventListener('click', () => {
        console.log("Mobile menu toggle clicked!");
        // Example: navMenu.classList.toggle('show-menu');
    });
}





/*=============== SHOP PAGE FILTERS TOGGLE ===============*/
const filtersToggle = document.getElementById('filters-toggle');
const filtersMenu = document.getElementById('shop-filters');
const filtersClose = document.getElementById('filters-close');

/* Show filters */
if (filtersToggle) {
    filtersToggle.addEventListener('click', () => {
        if (filtersMenu) {
            filtersMenu.classList.add('filters--open');
            document.body.classList.add('filters-active'); // إضافة كلاس للجسم
        }
    });
}

/* Hide filters */
if (filtersClose) {
    filtersClose.addEventListener('click', () => {
        if (filtersMenu) {
            filtersMenu.classList.remove('filters--open');
            document.body.classList.remove('filters-active'); // إزالة الكلاس من الجسم
        }
    });
}






/*=============== CART PAGE INTERACTIONS ===============*/
document.addEventListener('DOMContentLoaded', () => {
    const cartPage = document.querySelector('.cart-page-container');
    if (!cartPage) return; // Run only if we are on a page with cart container

    const updateCart = () => {
        let subtotal = 0;
        const cartItems = cartPage.querySelectorAll('.cart__item');
        
        if (cartItems.length === 0) {
            document.querySelector('.cart__container').classList.add('hidden');
            document.querySelector('.cart-empty').classList.remove('hidden');
            return;
        } else {
             document.querySelector('.cart__container').classList.remove('hidden');
            document.querySelector('.cart-empty').classList.add('hidden');
        }

        cartItems.forEach(item => {
            const priceElement = item.querySelector('.cart__item-price');
            const quantityInput = item.querySelector('.quantity-input');
            const totalElement = item.querySelector('.cart__item-total');
            
            const price = parseFloat(priceElement.getAttribute('data-price'));
            const quantity = parseInt(quantityInput.value);
            
            const lineTotal = price * quantity;
            totalElement.textContent = `${lineTotal.toFixed(2)} جنيه`;
            
            subtotal += lineTotal;
        });

        const subtotalElement = document.getElementById('cart-subtotal');
        const totalElement = document.getElementById('cart-total');

        subtotalElement.textContent = `${subtotal.toFixed(2)} جنيه`;
        totalElement.textContent = `${subtotal.toFixed(2)} جنيه`; // Assuming shipping is handled later
    };

    cartPage.addEventListener('click', (e) => {
        // Handle quantity buttons
        if (e.target.classList.contains('quantity-btn')) {
            const action = e.target.getAttribute('data-action');
            const input = e.target.parentElement.querySelector('.quantity-input');
            let currentValue = parseInt(input.value);

            if (action === 'increase') {
                input.value = currentValue + 1;
            } else if (action === 'decrease' && currentValue > 1) {
                input.value = currentValue - 1;
            }
            updateCart();
        }

        // Handle remove button
        if (e.target.closest('.cart__item-remove')) {
            e.target.closest('.cart__item').remove();
            updateCart();
        }
    });

    // Handle direct input change
     cartPage.addEventListener('change', (e) => {
        if(e.target.classList.contains('quantity-input')){
            if(e.target.value < 1){
                e.target.value = 1;
            }
            updateCart();
        }
     });

    // Initial cart update on page load
    updateCart();
});




/*=============== PROFILE PAGE TABS ===============*/
document.addEventListener('DOMContentLoaded', () => {
    const profileNav = document.querySelector('.profile__nav');
    if (!profileNav) return; // Run only if we are on profile page

    const navLinks = profileNav.querySelectorAll('.profile__nav-link');
    const profilePanels = document.querySelectorAll('.profile__panel');

    profileNav.addEventListener('click', (e) => {
        const clickedLink = e.target.closest('.profile__nav-link');
        if (!clickedLink) return;
        
        const targetId = clickedLink.getAttribute('data-target');
        if (!targetId) return; // For links like "Logout" that don't have a target

        e.preventDefault();

        // Update active link
        navLinks.forEach(link => link.classList.remove('active'));
        clickedLink.classList.add('active');

        // Show target panel
        profilePanels.forEach(panel => {
            if (panel.id === targetId) {
                panel.classList.remove('hidden');
            } else {
                panel.classList.add('hidden');
            }
        });
    });
});





/*=============== CHECKOUT PAGE INTERACTIONS ===============*/
document.addEventListener('DOMContentLoaded', () => {
    const checkoutContainer = document.querySelector('.checkout__container');
    if (!checkoutContainer) return; // Run only if on checkout page

    const shippingOptions = document.querySelectorAll('input[name="shipping_method"]');
    const paymentOptions = document.querySelectorAll('input[name="payment_method"]');
    const creditCardFields = document.getElementById('credit-card-fields');

    const subtotalElement = document.getElementById('summary-subtotal');
    const shippingElement = document.getElementById('summary-shipping');
    const totalElement = document.getElementById('summary-total');
    
    const updateTotal = () => {
        const subtotal = parseFloat(subtotalElement.textContent) || 0;
        const selectedShipping = document.querySelector('input[name="shipping_method"]:checked');
        const shippingCost = parseFloat(selectedShipping.getAttribute('data-cost'));

        shippingElement.textContent = `${shippingCost.toFixed(2)} جنيه`;
        totalElement.textContent = `${(subtotal + shippingCost).toFixed(2)} جنيه`;
    };

    // Update total on shipping change
    shippingOptions.forEach(option => {
        option.addEventListener('change', updateTotal);
    });

    // Toggle payment fields
    paymentOptions.forEach(option => {
        option.addEventListener('change', (e) => {
            if (e.target.value === 'card') {
                creditCardFields.classList.remove('hidden');
            } else {
                creditCardFields.classList.add('hidden');
            }
        });
    });

    // Initial calculation on page load
    updateTotal();
});