<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إتمام الطلب - VITO STORE</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header class="header header--minimal">
        <nav class="nav container">
            <a href="index.html" class="nav__logo">VITO STORE</a>
            <div class="secure-checkout">
                <i class='bx bxs-lock-alt'></i>
                <span>دفع آمن</span>
            </div>
        </nav>
    </header>

    <main>
        <form action="process_order.php" method="POST" class="checkout-form">
            <section class="checkout section">
                <div class="checkout__container container grid">
                    
                    <div class="checkout__form-details">
                        <div class="checkout__section">
                            <h3 class="checkout__section-title">تفاصيل الشحن</h3>
                            <div class="form__group">
                                <label for="name">الاسم الكامل</label>
                                <input type="text" name="customer_name" id="name" class="form__input" required>
                            </div>
                            <div class="form__group">
                                <label for="phone">رقم الهاتف</label>
                                <input type="tel" name="customer_phone" id="phone" class="form__input" required>
                            </div>
                            <div class="form__group">
                                <label for="city">المدينة</label>
                                <input type="text" name="customer_city" id="city" class="form__input" required>
                            </div>
                            <div class="form__group">
                                <label for="address">العنوان بالتفصيل</label>
                                <input type="text" name="customer_address" id="address" class="form__input" placeholder="اسم الشارع، رقم المبنى، رقم الشقة" required>
                            </div>
                        </div>

                        <div class="checkout__section">
                            <h3 class="checkout__section-title">طريقة الشحن</h3>
                            <div class="method__option">
                                <input type="radio" id="shipping-standard" name="shipping_method" value="standard" data-cost="50" checked>
                                <label for="shipping-standard">
                                    <span>شحن عادي (50.00 جنيه)</span>
                                    <small>يصل خلال 3-5 أيام عمل</small>
                                </label>
                            </div>
                            <div class="method__option">
                                <input type="radio" id="shipping-express" name="shipping_method" value="express" data-cost="100">
                                <label for="shipping-express">
                                    <span>شحن سريع (100.00 جنيه)</span>
                                    <small>يصل خلال 1-2 يوم عمل</small>
                                </label>
                            </div>
                        </div>

                        <div class="checkout__section">
                            <h3 class="checkout__section-title">طريقة الدفع</h3>
                            <div class="method__option">
                                <input type="radio" id="payment-cod" name="payment_method" value="cod" checked>
                                <label for="payment-cod">الدفع عند الاستلام</label>
                            </div>
                             <div class="method__option">
                                <input type="radio" id="payment-card" name="payment_method" value="card">
                                <label for="payment-card">الدفع بالبطاقة الائتمانية</label>
                            </div>
                            <div id="credit-card-fields" class="hidden">
                                <div class="form__group">
                                    <label for="card-number">رقم البطاقة</label>
                                    <input type="text" id="card-number" name="card_number" class="form__input">
                                </div>
                                </div>
                        </div>

                    </div>

                    <div class="checkout__order-summary">
                        <h3 class="checkout__section-title">ملخص طلبك</h3>
                        <div class="summary__items-list">
                            <div class="summary__item">
                                <img src="https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=100" alt="">
                                <div>
                                    <p>تيشيرت VITO قطني (x1)</p>
                                    <strong>250.00 جنيه</strong>
                                </div>
                            </div>
                             <div class="summary__item">
                                <img src="https://images.unsplash.com/photo-1602293589930-4535a9a7464b?w=100" alt="">
                                <div>
                                    <p>بنطلون جينز VITO (x2)</p>
                                    <strong>900.00 جنيه</strong>
                                </div>
                            </div>
                        </div>
                        <div class="summary__totals">
                            <div class="summary__line">
                                <span>المجموع الفرعي</span>
                                <span id="summary-subtotal">1150.00 جنيه</span>
                            </div>
                            <div class="summary__line">
                                <span>الشحن</span>
                                <span id="summary-shipping">50.00 جنيه</span>
                            </div>
                            <div class="summary__line summary__line--total">
                                <span>الإجمالي</span>
                                <span id="summary-total">1200.00 جنيه</span>
                            </div>
                        </div>
                    </div>
                     <button type="submit" class="button button--fullwidth">إتمام الطلب والدفع</button>
                </div>
            </section>
        </form>
    </main>

    <footer class="footer section">
        </footer>

    <script src="script.js"></script>
</body>
</html>