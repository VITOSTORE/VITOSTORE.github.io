<?php
// تضمين ملف الاتصال بقاعدة البيانات
require_once "config.php";

// الإعدادات الافتراضية لترقيم الصفحات
$products_per_page = 12; 
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $products_per_page;

// الاستعلام الأساسي لجلب المنتجات الأكثر مبيعًا فقط
$base_sql = " FROM products WHERE is_best_seller = 1";

// التعامل مع الترتيب
$sort_order = ' ORDER BY created_at DESC'; // الترتيب الافتراضي
if (!empty($_GET['sort'])) {
    switch ($_GET['sort']) {
        case 'price_asc':
            $sort_order = ' ORDER BY price ASC';
            break;
        case 'price_desc':
            $sort_order = ' ORDER BY price DESC';
            break;
        case 'newest':
            $sort_order = ' ORDER BY created_at DESC';
            break;
    }
}

// حساب إجمالي عدد المنتجات (لترقيم الصفحات)
$count_sql = "SELECT COUNT(*) " . $base_sql;
$count_result = mysqli_query($link, $count_sql);
$total_products = mysqli_fetch_row($count_result)[0];
$total_pages = ceil($total_products / $products_per_page);

// بناء الاستعلام النهائي لجلب المنتجات
$sql_products = "SELECT * " . $base_sql . $sort_order . " LIMIT $products_per_page OFFSET $offset";
$result_products = mysqli_query($link, $sql_products);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الأكثر مبيعًا - VITO STORE</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <header class="header" id="header">
        <nav class="nav container">
            <a href="index.php" class="nav__logo">VITO</a>
            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                    <li class="nav__item"><a href="index.php#home" class="nav__link"><i class='bx bx-home-alt-2'></i><span>الرئيسية</span></a></li>
                    <li class="nav__item"><a href="products.php" class="nav__link"><i class='bx bx-shopping-bag'></i><span>المنتجات</span></a></li>
                    <li class="nav__item"><a href="bestsellers.php" class="nav__link active-link"><i class='bx bxs-purchase-tag'></i><span>الأكثر مبيعًا</span></a></li>
                    <li class="nav__item"><a href="cart.html" class="nav__link"><i class='bx bx-cart'></i><span>السله</span></a></li>
                    <li class="nav__item"><a href="index.php#contact" class="nav__link"><i class='bx bx-phone'></i><span>تواصل</span></a></li>
                </ul>
            </div>
            <div class="nav__actions">
                <i class='bx bx-search nav__icon'></i>
                <i class='bx bx-shopping-bag nav__icon'></i>
                <i class='bx bx-user nav__icon'></i>
            </div>
        </nav>
    </header>

    <main>
        <section class="page__header">
            <div class="container">
                <h1 class="page__title">الأكثر مبيعًا</h1>
                <ul class="breadcrumbs">
                    <li><a href="index.php">الرئيسية</a></li>
                    <li>/</li>
                    <li>الأكثر مبيعًا</li>
                </ul>
            </div>
        </section>

        <section class="shop section">
            <div class="container">
                <form method="GET" action="bestsellers.php" id="sort-form">
                    <div class="shop__content">
                        <div class="shop__header shop__header--simple">
                            <select name="sort" class="shop__sort" onchange="document.getElementById('sort-form').submit()">
                                <option value="default" <?php echo (!isset($_GET['sort'])) ? 'selected' : ''; ?>>ترتيب حسب</option>
                                <option value="newest" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'newest') ? 'selected' : ''; ?>>الأحدث</option>
                                <option value="price_asc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_asc') ? 'selected' : ''; ?>>السعر: من الأقل للأعلى</option>
                                <option value="price_desc" <?php echo (isset($_GET['sort']) && $_GET['sort'] == 'price_desc') ? 'selected' : ''; ?>>السعر: من الأعلى للأقل</option>
                            </select>
                        </div>

                        <div class="products__container grid">
                            <?php
                            if (mysqli_num_rows($result_products) > 0) {
                                while ($product = mysqli_fetch_assoc($result_products)) {
                                    echo '<div class="product__card">';
                                    echo '    <div class="product__image"><a href="single-product.php?id=' . $product['id'] . '"><img src="' . htmlspecialchars($product['image_url']) . '" alt="' . htmlspecialchars($product['name']) . '"></a></div>';
                                    echo '    <div class="product__data">';
                                    echo '        <h3 class="product__name">' . htmlspecialchars($product['name']) . '</h3>';
                                    echo '        <p class="product__price">' . number_format($product['price'], 2) . ' جنيه</p>';
                                    echo '       echo '<form action="cart-handler.php" method="POST">';
                                      echo ' <input type="hidden" name="product_id" value="' . $product['id'] . '">';
                                      echo ' <input type="hidden" name="quantity" value="1">';
                                      echo ' <input type="hidden" name="action" value="add">';
                                      echo ' <button type="submit" class="button product__button">';
                                        echo ' <i class="bx bx-cart-add"></i><span>أضف للسلة</span>';
                                        echo ' </button>';
                                      echo '</form>';
                                    echo '    </div>';
                                    echo '</div>';
                                }
                            } else {
                                echo '<p>لا توجد منتجات هي الأكثر مبيعًا حاليًا.</p>';
                            }
                            ?>
                        </div>

                        <nav class="pagination">
                            <ul class="pagination__list">
                                <?php
                                if ($total_pages > 1) {
                                    for ($i = 1; $i <= $total_pages; $i++) {
                                        // الحفاظ على الترتيب عند التنقل بين الصفحات
                                        $query_params = $_GET;
                                        $query_params['page'] = $i;
                                        $href = 'bestsellers.php?' . http_build_query($query_params);
                                        $class = ($page == $i) ? 'current' : '';
                                        echo '<li><a href="' . $href . '" class="pagination__link ' . $class . '">' . $i . '</a></li>';
                                    }
                                }
                                ?>
                            </ul>
                        </nav>
                    </div>
                </form>
            </div>
        </section>
    </main>

    <footer class="footer section">
        <div class="footer__container container grid">
            <div class="footer__content">
                <h3 class="footer__title">VITO STORE</h3>
                <p class="footer__description">وجهتك الأولى للأناقة العصرية.</p>
            </div>
            <div class="footer__content">
                <h3 class="footer__title">أقسامنا</h3>
                <ul class="footer__links">
                    <li><a href="#" class="footer__link">الرجال</a></li>
                    <li><a href="#" class="footer__link">النساء</a></li>
                    <li><a href="#" class="footer__link">الأطفال</a></li>
                </ul>
            </div>
            <div class="footer__content">
                <h3 class="footer__title">تابعنا</h3>
                <div class="footer__social">
                    <a href="#" class="footer__social-link"><i class='bx bxl-facebook'></i></a>
                    <a href="#" class="footer__social-link"><i class='bx bxl-instagram-alt'></i></a>
                    <a href="#" class="footer__social-link"><i class='bx bxl-twitter'></i></a>
                </div>
            </div>
        </div>
        <p class="footer__copy">&#169; 2025 VITO STORE. جميع الحقوق محفوظة.</p>
    </footer>

    <a href="#" class="scrollup" id="scroll-up"><i class='bx bx-up-arrow-alt scrollup__icon'></i></a>

    <script src="script.js"></script>

</body>
</html>
<?php
// إغلاق الاتصال بقاعدة البيانات
mysqli_close($link);
?>